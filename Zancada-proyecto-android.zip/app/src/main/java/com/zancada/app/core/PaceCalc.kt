package com.zancada.app.core

import java.util.Locale
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Ritmos basados en la fórmula VDOT de Jack Daniels. */
object PaceCalc {
    fun vdotFromRace(distanceM: Double, timeSec: Double): Double {
        val t = timeSec / 60.0
        val v = distanceM / t
        val vo2 = -4.60 + 0.182258 * v + 0.000104 * v * v
        val pct = 0.8 + 0.1894393 * exp(-0.012778 * t) + 0.2989558 * exp(-0.1932605 * t)
        return vo2 / pct
    }

    /** Ritmo (s/km) al que se corre a una fracción del VO2max. */
    fun paceAtFraction(vdot: Double, fraction: Double): Int {
        val vo2 = fraction * vdot
        val a = 0.000104
        val b = 0.182258
        val c = -(4.60 + vo2)
        val v = (-b + sqrt(b * b - 4 * a * c)) / (2 * a) // m/min
        return (1000.0 / v * 60.0).roundToInt()
    }

    fun predictTimeSec(vdot: Double, distanceM: Double): Int {
        var lo = 3.0 * 60
        var hi = 12.0 * 3600
        repeat(60) {
            val mid = (lo + hi) / 2
            if (vdotFromRace(distanceM, mid) > vdot) lo = mid else hi = mid
        }
        return ((lo + hi) / 2).roundToInt()
    }

    fun initialVdot(level: Level, recent5kSec: Int): Double =
        vdotFromRace(5000.0, (if (recent5kSec > 0) recent5kSec else level.base5kSec).toDouble())
}

data class PaceZones(
    val easy: Int, val easyFast: Int, val easySlow: Int,
    val marathon: Int, val tempo: Int, val interval: Int, val repetition: Int
) {
    companion object {
        fun from(vdot: Double) = PaceZones(
            easy = PaceCalc.paceAtFraction(vdot, 0.66),
            easyFast = PaceCalc.paceAtFraction(vdot, 0.72),
            easySlow = PaceCalc.paceAtFraction(vdot, 0.60),
            marathon = PaceCalc.paceAtFraction(vdot, 0.81),
            tempo = PaceCalc.paceAtFraction(vdot, 0.88),
            interval = PaceCalc.paceAtFraction(vdot, 0.975),
            repetition = PaceCalc.paceAtFraction(vdot, 1.05)
        )
    }
}

object Fmt {
    fun pace(sec: Int): String = if (sec <= 0) "--:--" else String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)

    fun duration(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun km(meters: Double): String = String.format(Locale.US, "%.2f", meters / 1000.0)
    fun km1(km: Double): String = String.format(Locale.US, "%.1f", km)

    fun distance(meters: Int): String =
        if (meters < 1000) "$meters m" else {
            val k = meters / 1000.0
            if (meters % 1000 == 0) "${meters / 1000} km" else String.format(Locale.US, "%.1f km", k)
        }

    fun speechPace(sec: Int): String = "${sec / 60} minutos ${sec % 60} segundos"
}
