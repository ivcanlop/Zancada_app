package com.zancada.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.rememberRunStarter

@Composable
fun WorkoutDetailScreen(state: AppState) {
    val w = state.detail ?: return
    val startRun = rememberRunStarter(state)
    val done = w.id in state.done

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().clickable { state.detail = null }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás", tint = Z.Text)
            Text("  Atrás", fontSize = 16.sp)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag(w.type.label, typeColor(w.type))
                Tag(dayLong(w.date), Z.Muted)
            }
            Text(w.title, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text(w.description, color = Z.Muted, fontSize = 15.sp)

            if (w.isRun) {
                ZCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Stat(Fmt.distance(w.totalDistanceM), "Distancia")
                        Stat("~${w.estimatedSec / 60} min", "Duración")
                        Stat(Fmt.pace(w.estimatedSec * 1000 / w.totalDistanceM.coerceAtLeast(1)), "Ritmo medio")
                    }
                    Gap(16.dp)
                    StepProfileBar(w.steps)
                }
                SectionTitle("Estructura")
                ZCard {
                    w.steps.forEachIndexed { i, s ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Dot(stepColor(s.kind))
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(s.kind.label, fontWeight = FontWeight.SemiBold)
                                Text(Fmt.distance(s.distanceM), color = Z.Muted, fontSize = 12.sp)
                            }
                            Text("${Fmt.pace(s.paceSecKm)} /km", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(
                    "El entrenador por voz te avisará de cada tramo, de los kilómetros y de si vas demasiado rápido o lento.",
                    color = Z.Muted, fontSize = 12.sp
                )
            } else {
                SectionTitle("Ejercicios")
                ZCard {
                    w.strengthItems.forEachIndexed { i, t ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", color = Z.Lime, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 14.dp))
                            Text(t)
                        }
                    }
                }
            }
            Gap(8.dp)
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (w.isRun && !done) PrimaryButton("Empezar carrera") { startRun(w) }
            SecondaryButton(if (done) "Desmarcar como hecho" else "Marcar como hecho") { state.markDone(w, !done) }
        }
    }
}
