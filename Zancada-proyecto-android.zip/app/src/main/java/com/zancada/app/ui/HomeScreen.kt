package com.zancada.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.core.PaceZones
import com.zancada.app.core.Workout
import com.zancada.app.core.WorkoutType
import com.zancada.app.rememberRunStarter
import java.time.temporal.ChronoUnit

@Composable
fun HomeScreen(state: AppState) {
    val p = state.profile ?: return
    val startRun = rememberRunStarter(state)
    val week = state.currentWeek()
    val today = state.today()
    val todays = state.allWorkouts().filter { it.date == today }
    val next = state.nextWorkout()
    val hero: Workout? = todays.firstOrNull { it.id !in state.done } ?: todays.firstOrNull() ?: next
    val weeksLeft = state.plan.lastOrNull()?.let {
        (ChronoUnit.DAYS.between(today, it.start.plusDays(6)) / 7).coerceAtLeast(0)
    } ?: 0

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text(dayLong(today), color = Z.Muted, fontSize = 14.sp)
            Text("Hola, ${p.name}", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                if (week != null) "Semana ${week.index + 1} de ${p.planWeeks} · ${week.phase} · objetivo ${p.goal.label}"
                else if (today.isBefore(state.plan.firstOrNull()?.start ?: today)) "Tu plan aún no ha empezado"
                else "¡Plan completado! Crea uno nuevo desde Perfil",
                color = Z.Muted, fontSize = 13.sp
            )
        }

        // Semana
        if (week != null) {
            ZCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (i in 0 until 7) {
                        val d = week.start.plusDays(i.toLong())
                        val ws = week.workouts.filter { it.date == d }
                        val isDone = ws.isNotEmpty() && ws.all { it.id in state.done }
                        val isToday = d == today
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(dayShort(d).take(1), color = Z.Muted, fontSize = 12.sp)
                            Gap(6.dp)
                            Box(
                                Modifier.size(36.dp).clip(CircleShape)
                                    .background(
                                        when {
                                            isDone -> Z.Lime
                                            ws.isNotEmpty() -> typeColor(ws.first().type).copy(alpha = 0.22f)
                                            else -> Z.Surface2
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    if (isDone) "✓" else d.dayOfMonth.toString(),
                                    color = if (isDone) Color.Black else if (isToday) Z.Lime else Z.Text,
                                    fontWeight = if (isToday) FontWeight.ExtraBold else FontWeight.Medium,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
                Gap(14.dp)
                val plannedKm = week.totalKm
                val doneKm = week.workouts.filter { it.id in state.done }.sumOf { it.totalDistanceM } / 1000.0
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Esta semana", color = Z.Muted, fontSize = 13.sp)
                    Text("${Fmt.km1(doneKm)} / ${Fmt.km1(plannedKm)} km", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Gap(6.dp)
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Z.Surface2)) {
                    val frac = if (plannedKm > 0) (doneKm / plannedKm).coerceIn(0.0, 1.0).toFloat() else 0f
                    Box(Modifier.fillMaxWidth(frac).height(8.dp).clip(RoundedCornerShape(4.dp)).background(Z.Lime))
                }
            }
        }

        // Entrenamiento de hoy / próximo
        if (hero != null) {
            val isToday = hero.date == today
            val isDone = hero.id in state.done
            SectionTitle(if (isToday) "Entrenamiento de hoy" else "Próximo entrenamiento")
            ZCard(onClick = { state.detail = hero }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Tag(hero.type.label, typeColor(hero.type))
                    Text(if (isToday) "Hoy" else dayLong(hero.date), color = Z.Muted, fontSize = 13.sp)
                }
                Gap(10.dp)
                Text(hero.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Gap(4.dp)
                if (hero.isRun) {
                    Text(
                        "${Fmt.distance(hero.totalDistanceM)} · ~${hero.estimatedSec / 60} min",
                        color = Z.Muted, fontSize = 14.sp
                    )
                    Gap(14.dp)
                    StepProfileBar(hero.steps)
                } else {
                    Text("${hero.strengthItems.size} ejercicios · unos 25 min", color = Z.Muted, fontSize = 14.sp)
                }
                Gap(12.dp)
                Text(hero.description, color = Z.Muted, fontSize = 13.sp)
                Gap(14.dp)
                if (isDone) {
                    Tag("Completado ✓", Z.Lime)
                } else if (hero.isRun) {
                    PrimaryButton("Empezar carrera") { startRun(hero) }
                } else {
                    SecondaryButton("Ver ejercicios") { state.detail = hero }
                }
            }
        } else {
            ZCard { Text("No hay más entrenamientos en tu plan. ¡Buen trabajo!", color = Z.Muted) }
        }

        SecondaryButton("Carrera libre (sin plan)") { startRun(null) }

        // Ritmos
        val z = PaceZones.from(p.vdot)
        SectionTitle("Tus ritmos")
        ZCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat(Fmt.pace(z.easy), "Suave /km")
                Stat(Fmt.pace(z.tempo), "Tempo /km")
                Stat(Fmt.pace(z.interval), "Series /km")
            }
        }
        Gap(8.dp)
    }
}
