package com.zancada.app.core

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object PlanGenerator {

    private val REP_LENGTHS = intArrayOf(400, 600, 800, 1000, 1200)

    // Días de la semana (0 = lunes) para cada rol según días de entreno
    private data class Layout(val easy: List<Int>, val q1: Int, val q2: Int?, val recovery: Int?, val long: Int)

    private fun layout(days: Int): Layout = when (days) {
        3 -> Layout(listOf(3), 1, null, null, 6)
        4 -> Layout(listOf(5), 1, 3, null, 6)
        5 -> Layout(listOf(0, 5), 1, 3, null, 6)
        else -> Layout(listOf(0, 5), 1, 3, 2, 6)
    }

    private fun lerp(a: Double, b: Double, t: Double) = a + (b - a) * t
    private fun roundHalfKm(km: Double): Int = (((km * 2).roundToInt()) / 2.0 * 1000).toInt()

    fun generate(p: UserProfile): List<Week> {
        val start = LocalDate.ofEpochDay(p.planStartEpochDay)
            .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val n = p.planWeeks
        val z = PaceZones.from(p.vdot)
        val hasRace = p.goal != Goal.GENERAL
        val taper = when {
            !hasRace -> 0
            p.goal == Goal.FIVE_K || p.goal == Goal.TEN_K -> 1
            n >= 10 -> 2
            else -> 1
        }
        val build = n - taper
        val lay = layout(p.daysPerWeek.coerceIn(3, 6))
        val peak = p.goal.peakLongKm
        val startLong = min(p.level.startLongKm, peak * 0.7)
        val goalPace = (PaceCalc.predictTimeSec(p.vdot, p.goal.distanceKm * 1000) / p.goal.distanceKm).roundToInt()

        val weeks = ArrayList<Week>()
        for (w in 0 until n) {
            val weekStart = start.plusWeeks(w.toLong())
            val isRaceWeek = hasRace && w == n - 1
            val inTaper = w >= build
            val prog = if (inTaper) 1.0 else w.toDouble() / max(1, build - 1)
            val down = !inTaper && w % 4 == 3 && w < build - 1
            val factor = if (down) 0.8 else 1.0
            val phase = when {
                isRaceWeek -> "Semana de carrera"
                inTaper -> "Puesta a punto"
                prog < 0.35 -> "Base"
                prog < 0.75 -> "Construcción"
                else -> "Específica"
            }

            val longKm = when {
                inTaper -> peak * (if (taper == 2) (if (w == build) 0.7 else 0.45) else 0.55)
                else -> lerp(startLong, peak, prog) * factor
            }
            val easyKm = (longKm * 0.55).coerceIn(3.0, 10.0)
            val workouts = ArrayList<Workout>()
            fun date(dow: Int) = weekStart.plusDays(dow.toLong())
            fun id(dow: Int) = "w${w}d$dow"

            // Calidad 1 (series; en 3 días alterna con tempo)
            val q1Intervals = lay.q2 != null || w % 2 == 0
            val q1: Workout? = when {
                isRaceWeek -> null
                q1Intervals -> intervals(id(lay.q1), w, date(lay.q1), p, z, prog, if (inTaper) 0.6 else factor)
                else -> tempo(id(lay.q1), w, date(lay.q1), p, z, prog, if (inTaper) 0.6 else factor)
            }
            if (q1 != null) workouts.add(q1)
            else workouts.add(easyRun(id(lay.q1), w, date(lay.q1), WorkoutType.EASY, 3.5, z))

            lay.q2?.let { d ->
                if (isRaceWeek) workouts.add(easyRun(id(d), w, date(d), WorkoutType.EASY, 3.0, z))
                else workouts.add(tempo(id(d), w, date(d), p, z, prog, if (inTaper) 0.6 else factor))
            }
            lay.recovery?.let { d ->
                workouts.add(easyRun(id(d), w, date(d), WorkoutType.RECOVERY, max(3.0, easyKm * 0.6), z))
            }
            lay.easy.forEach { d ->
                val km = if (isRaceWeek) 3.0 else if (d == lay.easy.last()) easyKm * 0.85 else easyKm
                workouts.add(easyRun(id(d), w, date(d), WorkoutType.EASY, km, z))
            }
            // Tirada larga o carrera
            if (isRaceWeek) {
                val dist = (p.goal.distanceKm * 1000).toInt()
                workouts.add(
                    Workout(
                        id(lay.long), w, date(lay.long), WorkoutType.RACE,
                        "Carrera ${p.goal.label}",
                        "¡Es el gran día! Sal con calma los primeros kilómetros y deja lo mejor para el final.",
                        listOf(Step(StepKind.STEADY, dist, goalPace))
                    )
                )
            } else {
                workouts.add(longRun(id(lay.long), w, date(lay.long), p, z, longKm, prog, inTaper))
            }
            // Fuerza
            if (p.strength) {
                val used = workouts.map { it.date.dayOfWeek.value - 1 }.toSet()
                val d = listOf(2, 4, 0, 3).firstOrNull { it !in used }
                if (d != null) workouts.add(strength(id(d), w, date(d), w % 2 == 0))
            }
            weeks.add(Week(w, weekStart, phase, workouts.sortedBy { it.date }))
        }
        return weeks
    }

    private fun easyRun(id: String, w: Int, date: LocalDate, type: WorkoutType, km: Double, z: PaceZones): Workout {
        val dist = roundHalfKm(km)
        val pace = if (type == WorkoutType.RECOVERY) z.easySlow else z.easy
        val desc = if (type == WorkoutType.RECOVERY)
            "Carrera muy suave para recuperar. Debes poder hablar con total comodidad."
        else
            "Ritmo cómodo y conversacional. Construye base aeróbica sin acumular fatiga."
        return Workout(id, w, date, type, "${type.label} ${Fmt.distance(dist)}", desc, listOf(Step(StepKind.STEADY, dist, pace)))
    }

    private fun longRun(id: String, w: Int, date: LocalDate, p: UserProfile, z: PaceZones, km: Double, prog: Double, taper: Boolean): Workout {
        val dist = roundHalfKm(km)
        val steps = ArrayList<Step>()
        val specific = (p.goal == Goal.HALF || p.goal == Goal.MARATHON) && prog > 0.6 && !taper && w % 2 == 0
        val desc: String
        if (specific) {
            val mp = (dist * 0.3 / 500).toInt() * 500
            steps.add(Step(StepKind.STEADY, dist - mp, z.easy))
            steps.add(Step(StepKind.WORK, mp, z.marathon))
            desc = "Tirada larga con final a ritmo de carrera (${Fmt.distance(mp)}). Practica tu ritmo objetivo con fatiga."
        } else {
            steps.add(Step(StepKind.STEADY, dist, z.easy))
            desc = "El entrenamiento clave de la semana. Mantén un ritmo suave y constante y trabaja la resistencia."
        }
        return Workout(id, w, date, WorkoutType.LONG, "Tirada larga ${Fmt.distance(dist)}", desc, steps)
    }

    private fun intervals(id: String, w: Int, date: LocalDate, p: UserProfile, z: PaceZones, prog: Double, factor: Double): Workout {
        val workKm = lerp(p.level.intervalKm.first, p.level.intervalKm.second, prog) * factor
        var idx = (prog * 4.99).toInt().coerceIn(0, 4)
        if (p.level == Level.BEGINNER) idx = min(idx, 2)
        val rep = REP_LENGTHS[idx]
        val count = max(3, (workKm * 1000 / rep).roundToInt())
        val rec = max(200, ((rep / 2) / 100) * 100)
        val warm = if (p.level == Level.BEGINNER) 1000 else 1500
        val steps = ArrayList<Step>()
        steps.add(Step(StepKind.WARMUP, warm, z.easy))
        for (i in 0 until count) {
            steps.add(Step(StepKind.WORK, rep, z.interval))
            if (i < count - 1) steps.add(Step(StepKind.RECOVERY, rec, z.easySlow))
        }
        steps.add(Step(StepKind.COOLDOWN, warm, z.easy))
        return Workout(
            id, w, date, WorkoutType.INTERVALS, "Series $count×${rep} m",
            "Series rápidas con trote suave entre repeticiones. Mejoran tu velocidad y tu economía de carrera.",
            steps
        )
    }

    private fun tempo(id: String, w: Int, date: LocalDate, p: UserProfile, z: PaceZones, prog: Double, factor: Double): Workout {
        val km = lerp(p.level.tempoKm.first, p.level.tempoKm.second, prog) * factor
        val block = max(1500, roundHalfKm(km))
        val warm = if (p.level == Level.BEGINNER) 1000 else 1500
        val steps = listOf(
            Step(StepKind.WARMUP, warm, z.easy),
            Step(StepKind.WORK, block, z.tempo),
            Step(StepKind.COOLDOWN, warm, z.easy)
        )
        return Workout(
            id, w, date, WorkoutType.TEMPO, "Tempo ${Fmt.distance(block)}",
            "Bloque continuo a ritmo «cómodamente duro». Sube tu umbral y tu capacidad de sostener ritmo.",
            steps
        )
    }

    private fun strength(id: String, w: Int, date: LocalDate, a: Boolean): Workout {
        val items = if (a) listOf(
            "Movilidad de cadera y tobillo · 5 min",
            "Sentadillas · 3×12",
            "Zancadas alternas · 3×10 por pierna",
            "Puente de glúteo · 3×15",
            "Plancha frontal · 3×40 s",
            "Elevaciones de talón · 3×15"
        ) else listOf(
            "Movilidad de cadera y tobillo · 5 min",
            "Peso muerto a una pierna · 3×8 por lado",
            "Sentadilla búlgara · 3×8 por pierna",
            "Plancha lateral · 3×30 s por lado",
            "Bicho muerto · 3×10",
            "Saltos suaves de comba · 3×30 s"
        )
        return Workout(
            id, w, date, WorkoutType.STRENGTH, "Fuerza y movilidad",
            "Fortalece piernas y core para prevenir lesiones y correr más eficiente. Unos 25 minutos.",
            emptyList(), items
        )
    }
}
