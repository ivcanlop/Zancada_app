package com.zancada.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.core.RunRecord
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

private fun RunRecord.date(): LocalDate = Instant.ofEpochMilli(id).atZone(ZoneId.systemDefault()).toLocalDate()

@Composable
fun ActivityScreen(state: AppState) {
    val runs = state.runs.sortedByDescending { it.id }
    val today = LocalDate.now()
    val monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    // últimas 8 semanas
    val weekly = (7 downTo 0).map { back ->
        val ws = monday.minusWeeks(back.toLong())
        val km = runs.filter { val d = it.date(); !d.isBefore(ws) && d.isBefore(ws.plusDays(7)) }.sumOf { it.distanceM } / 1000.0
        ws to km
    }
    val thisWeek = weekly.last().second
    val totalKm = runs.sumOf { it.distanceM } / 1000.0
    val longest = runs.maxByOrNull { it.distanceM }
    val bestSplit = runs.flatMap { it.splitsSec }.minOrNull()
    val fastest5 = runs.filter { it.distanceM >= 5000 }.minByOrNull { it.avgPaceSecKm }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Actividad", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }
        item {
            ZCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat(Fmt.km1(thisWeek), "km esta semana")
                    Stat(Fmt.km1(totalKm), "km totales")
                    Stat("${runs.size}", "carreras")
                }
                Gap(16.dp)
                val maxKm = (weekly.maxOf { it.second }).coerceAtLeast(5.0)
                Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                    val n = weekly.size
                    val slot = size.width / n
                    val bw = slot * 0.55f
                    weekly.forEachIndexed { i, (_, km) ->
                        val h = (km / maxKm).toFloat() * (size.height - 8f)
                        drawRoundRect(
                            color = if (i == n - 1) Z.Lime else Z.Violet,
                            topLeft = Offset(i * slot + (slot - bw) / 2, size.height - h.coerceAtLeast(4f)),
                            size = Size(bw, h.coerceAtLeast(4f)),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                    }
                }
                Text("Kilómetros por semana (últimas 8)", color = Z.Muted, fontSize = 12.sp)
            }
        }
        if (runs.isNotEmpty()) {
            item {
                ZCard {
                    Text("Marcas personales", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Gap(8.dp)
                    if (longest != null) PbRow("Carrera más larga", "${Fmt.km(longest.distanceM)} km")
                    if (bestSplit != null) PbRow("Km más rápido", "${Fmt.pace(bestSplit)} /km")
                    if (fastest5 != null) PbRow("Mejor ritmo en ≥5 km", "${Fmt.pace(fastest5.avgPaceSecKm)} /km")
                }
            }
            item { SectionTitle("Historial") }
            items(runs) { r ->
                ZCard(onClick = { state.summaryRun = r }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title, fontWeight = FontWeight.SemiBold)
                            Text(dayLong(r.date()), color = Z.Muted, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${Fmt.km(r.distanceM)} km", fontWeight = FontWeight.ExtraBold, color = Z.Lime)
                            Text("${Fmt.duration(r.durationSec)} · ${Fmt.pace(r.avgPaceSecKm)}/km", color = Z.Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            item { ZCard { Text("Aún no has registrado carreras. Empieza tu primer entrenamiento desde la pestaña Hoy.", color = Z.Muted) } }
        }
    }
}

@Composable
private fun PbRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Z.Muted)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
