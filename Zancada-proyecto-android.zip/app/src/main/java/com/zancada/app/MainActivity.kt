package com.zancada.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.zancada.app.core.Workout
import com.zancada.app.data.Storage
import com.zancada.app.tracking.RunService
import com.zancada.app.tracking.RunSession
import com.zancada.app.tracking.RunStatus
import com.zancada.app.ui.ActivityScreen
import com.zancada.app.ui.AppState
import com.zancada.app.ui.HomeScreen
import com.zancada.app.ui.OnboardingScreen
import com.zancada.app.ui.PlanScreen
import com.zancada.app.ui.ProfileScreen
import com.zancada.app.ui.RunScreen
import com.zancada.app.ui.SummaryScreen
import com.zancada.app.ui.WorkoutDetailScreen
import com.zancada.app.ui.Z
import com.zancada.app.ui.ZancadaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val storage = Storage(this)
        setContent {
            ZancadaTheme {
                val state = remember { AppState(storage) }
                App(state)
            }
        }
    }
}

@Composable
fun App(state: AppState) {
    val run by RunSession.state.collectAsState()

    LaunchedEffect(run.status) {
        if (run.status == RunStatus.FINISHED) {
            state.reload()
            val rec = run.lastRecord
            if (rec != null) state.summaryRun = rec else RunSession.reset()
        }
    }

    BackHandler(enabled = state.detail != null && state.summaryRun == null) { state.detail = null }

    Box(Modifier.fillMaxSize().background(Z.Bg)) {
        when {
            state.profile == null || state.editingPlan -> OnboardingScreen(state)
            run.status == RunStatus.RUNNING || run.status == RunStatus.PAUSED -> RunScreen(run)
            state.summaryRun != null -> SummaryScreen(state)
            state.detail != null -> WorkoutDetailScreen(state)
            else -> MainScaffold(state)
        }
    }
}

@Composable
private fun MainScaffold(state: AppState) {
    val items: List<Pair<String, ImageVector>> = listOf(
        "Hoy" to Icons.Filled.Home,
        "Plan" to Icons.Filled.DateRange,
        "Actividad" to Icons.Filled.List,
        "Perfil" to Icons.Filled.Person
    )
    Scaffold(
        containerColor = Z.Bg,
        bottomBar = {
            NavigationBar(containerColor = Z.Surface) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = state.tab == i,
                        onClick = { state.tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Z.Lime,
                            selectedTextColor = Z.Lime,
                            indicatorColor = Z.VioletSoft,
                            unselectedIconColor = Z.Muted,
                            unselectedTextColor = Z.Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (state.tab) {
                0 -> HomeScreen(state)
                1 -> PlanScreen(state)
                2 -> ActivityScreen(state)
                else -> ProfileScreen(state)
            }
        }
    }
}

private fun hasLocation(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

/** Devuelve una función que pide permisos si hace falta y arranca la carrera (null = carrera libre). */
@Composable
fun rememberRunStarter(state: AppState): (Workout?) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Workout?>(null) }

    fun begin(w: Workout?) {
        RunSession.pendingWorkout = w
        RunSession.voiceEnabled = state.profile?.voiceCues ?: true
        RunService.send(ctx, RunService.ACTION_START)
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) begin(pending)
        else Toast.makeText(ctx, "Necesito el permiso de ubicación precisa para registrar la carrera", Toast.LENGTH_LONG).show()
    }

    return { w ->
        pending = w
        if (hasLocation(ctx)) begin(w)
        else {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            launcher.launch(perms.toTypedArray())
        }
    }
}
