package com.zancada.app.core

import java.time.LocalDate

enum class Goal(val label: String, val distanceKm: Double, val peakLongKm: Double) {
    FIVE_K("5K", 5.0, 10.0),
    TEN_K("10K", 10.0, 14.0),
    HALF("Media maratón", 21.0975, 20.0),
    MARATHON("Maratón", 42.195, 32.0),
    GENERAL("Mejorar mi forma", 5.0, 12.0)
}

enum class Level(
    val label: String,
    val desc: String,
    val base5kSec: Int,
    val startLongKm: Double,
    val intervalKm: Pair<Double, Double>,
    val tempoKm: Pair<Double, Double>
) {
    BEGINNER("Principiante", "Corro poco o estoy empezando", 32 * 60, 5.0, 1.6 to 3.0, 1.5 to 3.0),
    INTERMEDIATE("Intermedio", "Corro con regularidad", 28 * 60, 8.0, 3.0 to 5.0, 3.0 to 6.0),
    ADVANCED("Avanzado", "Entreno y compito", 23 * 60, 10.0, 4.0 to 7.0, 4.0 to 8.0)
}

enum class WorkoutType(val label: String) {
    EASY("Rodaje suave"),
    RECOVERY("Recuperación"),
    INTERVALS("Series"),
    TEMPO("Tempo"),
    LONG("Tirada larga"),
    STRENGTH("Fuerza y movilidad"),
    RACE("Día de carrera")
}

enum class StepKind(val label: String) {
    WARMUP("Calentamiento"),
    WORK("Rápido"),
    RECOVERY("Trote suave"),
    COOLDOWN("Vuelta a la calma"),
    STEADY("Ritmo constante")
}

data class Step(val kind: StepKind, val distanceM: Int, val paceSecKm: Int)

data class Workout(
    val id: String,
    val weekIndex: Int,
    val date: LocalDate,
    val type: WorkoutType,
    val title: String,
    val description: String,
    val steps: List<Step>,
    val strengthItems: List<String> = emptyList()
) {
    val totalDistanceM: Int get() = steps.sumOf { it.distanceM }
    val estimatedSec: Int get() = steps.sumOf { it.distanceM / 1000.0 * it.paceSecKm }.toInt()
    val isRun: Boolean get() = steps.isNotEmpty()
}

data class Week(
    val index: Int,
    val start: LocalDate,
    val phase: String,
    val workouts: List<Workout>
) {
    val totalKm: Double get() = workouts.sumOf { it.totalDistanceM } / 1000.0
}

data class UserProfile(
    val name: String,
    val goal: Goal,
    val level: Level,
    val daysPerWeek: Int,
    val planWeeks: Int,
    val planStartEpochDay: Long,
    val recent5kSec: Int,
    val vdot: Double,
    val strength: Boolean,
    val voiceCues: Boolean
)

data class LatLon(val lat: Double, val lon: Double)

data class RunRecord(
    val id: Long,
    val workoutId: String?,
    val title: String,
    val distanceM: Double,
    val durationSec: Int,
    val points: List<LatLon>,
    val splitsSec: List<Int>,
    val feedback: Int // 0 sin valorar, 1 muy fácil, 2 perfecto, 3 duro
) {
    val avgPaceSecKm: Int get() = if (distanceM > 50) (durationSec / (distanceM / 1000.0)).toInt() else 0
}
