package com.zancada.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.core.PaceCalc
import com.zancada.app.core.PaceZones

@Composable
fun ProfileScreen(state: AppState) {
    val p = state.profile ?: return
    val z = PaceZones.from(p.vdot)
    var showTime by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    var timeText by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(p.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("${p.goal.label} · ${p.level.label} · nivel VDOT ${Fmt.km1(p.vdot)}", color = Z.Muted, fontSize = 13.sp)

        SectionTitle("Zonas de ritmo")
        ZCard {
            ZoneRow("Recuperación", "${Fmt.pace(z.easySlow)} /km", Z.Teal)
            ZoneRow("Suave", "${Fmt.pace(z.easyFast)} – ${Fmt.pace(z.easySlow)} /km", Z.Teal)
            ZoneRow("Maratón", "${Fmt.pace(z.marathon)} /km", Z.Violet)
            ZoneRow("Tempo / umbral", "${Fmt.pace(z.tempo)} /km", Z.Red)
            ZoneRow("Series", "${Fmt.pace(z.interval)} /km", Z.Orange)
            ZoneRow("Repeticiones cortas", "${Fmt.pace(z.repetition)} /km", Z.Lime)
        }

        SectionTitle("Marcas previstas")
        ZCard {
            listOf("5K" to 5000.0, "10K" to 10000.0, "Media maratón" to 21097.5, "Maratón" to 42195.0).forEach { (n, d) ->
                ZoneRow(n, Fmt.duration(PaceCalc.predictTimeSec(p.vdot, d)), Z.Text)
            }
            Gap(4.dp)
            Text("Estimaciones según tu nivel actual. Se ajustan con tus valoraciones tras cada carrera.", color = Z.Muted, fontSize = 12.sp)
        }

        SecondaryButton("Actualizar nivel con un tiempo de 5K") { showTime = true }

        SectionTitle("Ajustes")
        ZCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Entrenador por voz", Modifier.weight(1f))
                Switch(p.voiceCues, { state.saveProfile(p.copy(voiceCues = it)) })
            }
            Gap(8.dp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Sesión de fuerza semanal", Modifier.weight(1f))
                Switch(p.strength, { state.saveProfile(p.copy(strength = it)) })
            }
        }
        SecondaryButton("Cambiar objetivo o rehacer plan") { state.editingPlan = true }
        SecondaryButton("Borrar todos mis datos") { showReset = true }
        Text("Zancada · gratis y sin anuncios. Tus datos se guardan solo en este móvil.", color = Z.Muted, fontSize = 12.sp)
        Gap(8.dp)
    }

    if (showTime) {
        val sec = parseTime(timeText)
        val valid = sec != null && sec in 720..3600
        AlertDialog(
            onDismissRequest = { showTime = false },
            title = { Text("Tu tiempo de 5K") },
            text = {
                Column {
                    Text("Introduce un 5K reciente o un test a tope (mm:ss).", color = Z.Muted, fontSize = 13.sp)
                    Gap(8.dp)
                    OutlinedTextField(
                        value = timeText, onValueChange = { timeText = it.take(8) },
                        singleLine = true, isError = timeText.isNotEmpty() && !valid, colors = fieldColors(),
                        label = { Text("p. ej. 26:45") }
                    )
                }
            },
            confirmButton = {
                TextButton(enabled = valid, onClick = {
                    state.setVdot(PaceCalc.vdotFromRace(5000.0, sec!!.toDouble()))
                    showTime = false; timeText = ""
                }) { Text("Guardar", color = if (valid) Z.Lime else Z.Muted) }
            },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text("Cancelar") } },
            containerColor = Z.Surface
        )
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("¿Borrar todo?") },
            text = { Text("Se eliminarán tu plan, tus carreras y tu perfil.") },
            confirmButton = { TextButton(onClick = { showReset = false; state.resetAll() }) { Text("Borrar", color = Z.Red) } },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancelar") } },
            containerColor = Z.Surface
        )
    }
}

@Composable
private fun ZoneRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Dot(color)
            Text("  $label", color = Z.Text)
        }
        Text(value, fontWeight = FontWeight.Bold)
    }
}
