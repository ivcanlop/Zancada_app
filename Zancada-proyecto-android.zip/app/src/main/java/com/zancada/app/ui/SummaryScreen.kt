package com.zancada.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.tracking.RunSession
import java.time.Instant
import java.time.ZoneId

@Composable
fun SummaryScreen(state: AppState) {
    val r = state.summaryRun ?: return
    var feedback by remember(r.id) { mutableIntStateOf(r.feedback) }
    var askDelete by remember { mutableStateOf(false) }
    val date = Instant.ofEpochMilli(r.id).atZone(ZoneId.systemDefault()).toLocalDate()

    fun close() {
        state.summaryRun = null
        RunSession.reset()
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(dayLong(date), color = Z.Muted)
            Text(r.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            ZCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat(Fmt.km(r.distanceM), "km", 32.sp)
                    Stat(Fmt.duration(r.durationSec), "Tiempo", 32.sp)
                    Stat(Fmt.pace(r.avgPaceSecKm), "Ritmo /km", 32.sp)
                }
            }
            if (r.points.size >= 2) {
                ZCard { RouteCanvas(r.points, Modifier.fillMaxWidth().height(200.dp)) }
            }
            if (r.splitsSec.isNotEmpty()) {
                SectionTitle("Parciales por km")
                ZCard {
                    val best = r.splitsSec.minOrNull() ?: 1
                    val worst = r.splitsSec.maxOrNull() ?: 1
                    r.splitsSec.forEachIndexed { i, s ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(28.dp), color = Z.Muted)
                            val frac = if (worst == best) 1f else 1f - 0.6f * ((s - best).toFloat() / (worst - best))
                            Box(Modifier.weight(1f)) {
                                Box(
                                    Modifier.fillMaxWidth(frac.coerceIn(0.3f, 1f)).height(14.dp)
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(if (s == best) Z.Lime else Z.Violet)
                                )
                            }
                            Text(Fmt.pace(s), Modifier.width(54.dp), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            if (r.workoutId != null) {
                SectionTitle("¿Cómo te has sentido?")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Muy fácil", feedback == 1, Modifier.weight(1f)) { feedback = 1; state.applyFeedback(r, 1) }
                    Chip("Perfecto", feedback == 2, Modifier.weight(1f)) { feedback = 2; state.applyFeedback(r, 2) }
                    Chip("Duro", feedback == 3, Modifier.weight(1f)) { feedback = 3; state.applyFeedback(r, 3) }
                }
                Text(
                    "Tu valoración ajusta los ritmos de los próximos entrenos. Solo cuenta la primera vez.",
                    color = Z.Muted, fontSize = 12.sp
                )
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PrimaryButton("Listo") { close() }
            SecondaryButton("Eliminar carrera") { askDelete = true }
        }
    }

    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text("¿Eliminar esta carrera?") },
            text = { Text("No se podrá recuperar.") },
            confirmButton = { TextButton(onClick = { askDelete = false; state.deleteRun(r); close() }) { Text("Eliminar", color = Z.Red) } },
            dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Cancelar") } },
            containerColor = Z.Surface
        )
    }
}
