package com.zancada.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Z {
    val Bg = Color(0xFF0A0A12)
    val Surface = Color(0xFF15151F)
    val Surface2 = Color(0xFF1F1F2D)
    val Line = Color(0xFF2B2B3C)
    val Violet = Color(0xFF7B5CFF)
    val VioletSoft = Color(0xFF2A2250)
    val Lime = Color(0xFFC8FF3D)
    val Text = Color(0xFFF4F4FA)
    val Muted = Color(0xFF9A9AB2)
    val Red = Color(0xFFFF5D6C)
    val Orange = Color(0xFFFFA64D)
    val Teal = Color(0xFF3DDBC0)
}

private val scheme = darkColorScheme(
    primary = Z.Violet,
    onPrimary = Color.White,
    secondary = Z.Lime,
    onSecondary = Color.Black,
    background = Z.Bg,
    onBackground = Z.Text,
    surface = Z.Surface,
    onSurface = Z.Text,
    surfaceVariant = Z.Surface2,
    onSurfaceVariant = Z.Muted,
    outline = Z.Line,
    error = Z.Red
)

@Composable
fun ZancadaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
