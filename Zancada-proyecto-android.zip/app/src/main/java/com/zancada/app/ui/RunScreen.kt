package com.zancada.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.core.StepKind
import com.zancada.app.tracking.RunService
import com.zancada.app.tracking.RunStatus
import com.zancada.app.tracking.RunUiState

@Composable
fun RunScreen(run: RunUiState) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val paused = run.status == RunStatus.PAUSED
    BackHandler { /* evita salir sin querer durante la carrera */ }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(run.workout?.title ?: "Carrera libre", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Tag(if (paused) "En pausa" else run.gpsMessage, if (paused) Z.Orange else if (run.gpsAccuracy in 0f..20f) Z.Lime else Z.Orange)
        }

        val w = run.workout
        if (w != null && w.steps.isNotEmpty()) {
            Gap(14.dp)
            ZCard(color = Z.Surface) {
                if (run.stepIndex < w.steps.size) {
                    val s = w.steps[run.stepIndex]
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.kind.label, color = stepColor(s.kind), fontWeight = FontWeight.Bold)
                        Text("Objetivo ${Fmt.pace(s.paceSecKm)} /km", fontWeight = FontWeight.Bold)
                    }
                    Text("Quedan ${Fmt.distance(run.stepRemainingM.toInt())} de este tramo", color = Z.Muted, fontSize = 13.sp)
                } else {
                    Text("Entrenamiento completado. Sigue suave o termina.", color = Z.Lime, fontWeight = FontWeight.Bold)
                }
                Gap(10.dp)
                StepProfileBar(w.steps, activeIndex = run.stepIndex)
            }
        }

        Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(Fmt.km(run.distanceM), fontSize = 88.sp, fontWeight = FontWeight.Black, color = Z.Lime)
            Text("kilómetros", color = Z.Muted, fontSize = 16.sp)
            Gap(24.dp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat(Fmt.duration(run.elapsedSec), "Tiempo", 38.sp)
                Stat(Fmt.pace(run.paceSecKm), "Ritmo /km", 38.sp)
            }
            if (run.points.size >= 2) {
                Gap(16.dp)
                RouteCanvas(run.points, Modifier.fillMaxWidth().height(120.dp))
            }
        }

        if (paused) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SecondaryButton("Terminar", Modifier.weight(1f)) { confirm = true }
                PrimaryButton("Continuar", Modifier.weight(1f)) { RunService.send(ctx, RunService.ACTION_RESUME) }
            }
        } else {
            PrimaryButton("Pausar") { RunService.send(ctx, RunService.ACTION_PAUSE) }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("¿Terminar la carrera?") },
            text = { Text("Se guardará con ${Fmt.km(run.distanceM)} km en ${Fmt.duration(run.elapsedSec)}.") },
            confirmButton = {
                TextButton(onClick = { confirm = false; RunService.send(ctx, RunService.ACTION_STOP) }) { Text("Terminar", color = Z.Lime) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Seguir") } },
            containerColor = Z.Surface
        )
    }
}
