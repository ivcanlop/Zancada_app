package com.zancada.app.tracking

import com.zancada.app.core.LatLon
import com.zancada.app.core.RunRecord
import com.zancada.app.core.Workout
import kotlinx.coroutines.flow.MutableStateFlow

enum class RunStatus { IDLE, RUNNING, PAUSED, FINISHED }

data class RunUiState(
    val status: RunStatus = RunStatus.IDLE,
    val elapsedSec: Int = 0,
    val distanceM: Double = 0.0,
    val paceSecKm: Int = 0,
    val gpsAccuracy: Float = -1f,
    val gpsMessage: String = "Buscando GPS…",
    val stepIndex: Int = 0,
    val stepRemainingM: Double = 0.0,
    val workout: Workout? = null,
    val points: List<LatLon> = emptyList(),
    val lastRecord: RunRecord? = null
)

/** Estado compartido entre el servicio de seguimiento y la interfaz (mismo proceso). */
object RunSession {
    val state = MutableStateFlow(RunUiState())

    @Volatile var pendingWorkout: Workout? = null
    @Volatile var voiceEnabled: Boolean = true

    fun reset() {
        pendingWorkout = null
        state.value = RunUiState()
    }
}
