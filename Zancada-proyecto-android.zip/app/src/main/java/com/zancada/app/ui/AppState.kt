package com.zancada.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.zancada.app.core.PlanGenerator
import com.zancada.app.core.RunRecord
import com.zancada.app.core.UserProfile
import com.zancada.app.core.Week
import com.zancada.app.core.Workout
import com.zancada.app.data.Storage
import java.time.LocalDate

class AppState(val storage: Storage) {
    var profile by mutableStateOf(storage.loadProfile())
        private set
    var runs by mutableStateOf(storage.loadRuns())
        private set
    var done by mutableStateOf(storage.loadDone())
        private set
    var plan by mutableStateOf<List<Week>>(emptyList())
        private set

    var tab by mutableIntStateOf(0)
    var detail by mutableStateOf<Workout?>(null)
    var summaryRun by mutableStateOf<RunRecord?>(null)
    var editingPlan by mutableStateOf(false)

    init {
        refreshPlan()
    }

    private fun refreshPlan() {
        plan = profile?.let { PlanGenerator.generate(it) } ?: emptyList()
    }

    fun reload() {
        runs = storage.loadRuns()
        done = storage.loadDone()
    }

    fun saveProfile(p: UserProfile) {
        storage.saveProfile(p)
        profile = p
        refreshPlan()
    }

    /** Nuevo plan: las marcas de completado del plan anterior dejan de aplicar. */
    fun restartPlan(p: UserProfile) {
        storage.clearDone()
        saveProfile(p)
        reload()
    }

    fun setVdot(v: Double) {
        profile?.let { saveProfile(it.copy(vdot = v.coerceIn(20.0, 75.0))) }
    }

    fun markDone(w: Workout, value: Boolean) {
        if (value) storage.markDone(w.id, 0L) else storage.unmarkDone(w.id)
        reload()
    }

    fun deleteRun(r: RunRecord) {
        storage.deleteRun(r.id)
        reload()
    }

    /** Valoración tras la carrera: ajusta el nivel (VDOT) en sesiones de calidad. */
    fun applyFeedback(r: RunRecord, fb: Int) {
        val current = storage.loadRuns().firstOrNull { it.id == r.id } ?: return
        val first = current.feedback == 0
        storage.setFeedback(r.id, fb)
        val w = r.workoutId?.let { id -> plan.flatMap { it.workouts }.firstOrNull { it.id == id } }
        val p = profile
        if (first && w != null && p != null) {
            val delta = when (fb) { 1 -> 0.6; 3 -> -0.6; else -> 0.0 }
            if (delta != 0.0) saveProfile(p.copy(vdot = (p.vdot + delta).coerceIn(20.0, 75.0)))
        }
        reload()
    }

    fun resetAll() {
        storage.clearAll()
        profile = null
        runs = emptyList()
        done = emptyMap()
        plan = emptyList()
        tab = 0
        detail = null
        summaryRun = null
        editingPlan = false
    }

    fun today(): LocalDate = LocalDate.now()

    fun allWorkouts(): List<Workout> = plan.flatMap { it.workouts }

    fun currentWeek(): Week? {
        val t = today()
        return plan.firstOrNull { !t.isBefore(it.start) && t.isBefore(it.start.plusDays(7)) }
    }

    fun nextWorkout(): Workout? {
        val t = today()
        return allWorkouts().firstOrNull { !it.date.isBefore(t) && it.id !in done }
    }
}
