package com.zancada.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.core.Goal
import com.zancada.app.core.Level
import com.zancada.app.core.PaceCalc
import com.zancada.app.core.PaceZones
import com.zancada.app.core.UserProfile
import java.time.LocalDate

fun parseTime(s: String): Int? {
    val t = s.trim()
    if (t.isEmpty()) return 0
    val parts = t.split(":")
    return try {
        when (parts.size) {
            2 -> parts[0].toInt() * 60 + parts[1].toInt()
            3 -> parts[0].toInt() * 3600 + parts[1].toInt() * 60 + parts[2].toInt()
            else -> null
        }
    } catch (e: Exception) {
        null
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Z.Violet, unfocusedBorderColor = Z.Line,
    focusedTextColor = Z.Text, unfocusedTextColor = Z.Text,
    cursorColor = Z.Lime, focusedLabelColor = Z.Violet, unfocusedLabelColor = Z.Muted
)

@Composable
fun OnboardingScreen(state: AppState) {
    val existing = state.profile
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var goal by remember { mutableStateOf(existing?.goal ?: Goal.TEN_K) }
    var level by remember { mutableStateOf(existing?.level ?: Level.BEGINNER) }
    var fiveK by remember { mutableStateOf(if ((existing?.recent5kSec ?: 0) > 0) Fmt.duration(existing!!.recent5kSec) else "") }
    var days by remember { mutableIntStateOf(existing?.daysPerWeek ?: 4) }
    var weeks by remember { mutableIntStateOf(existing?.planWeeks ?: 12) }
    var strength by remember { mutableStateOf(existing?.strength ?: true) }
    var voice by remember { mutableStateOf(existing?.voiceCues ?: true) }

    fun weekOptions(g: Goal) = when (g) {
        Goal.FIVE_K -> listOf(6, 8, 10, 12)
        Goal.TEN_K -> listOf(8, 10, 12, 16)
        Goal.HALF -> listOf(10, 12, 16, 20)
        Goal.MARATHON -> listOf(12, 16, 20, 24)
        Goal.GENERAL -> listOf(4, 8, 12)
    }

    val fiveKSec = parseTime(fiveK)
    val fiveKValid = fiveKSec != null && (fiveKSec == 0 || fiveKSec in 720..3600)
    val total = 5

    BackHandler(enabled = step > 0 || state.editingPlan) {
        if (step > 0) step-- else state.editingPlan = false
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0 until total) {
                Box(
                    Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (i <= step) Z.Lime else Z.Surface2)
                )
            }
        }
        Gap(20.dp)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            when (step) {
                0 -> {
                    Text("Zancada", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = Z.Lime)
                    Text("Tu plan de carrera personal. Gratis, sin suscripción.", color = Z.Muted, fontSize = 16.sp)
                    Gap(28.dp)
                    Text("¿Cómo te llamas?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Gap(10.dp)
                    OutlinedTextField(
                        value = name, onValueChange = { name = it.take(24) },
                        label = { Text("Nombre") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                    )
                }
                1 -> {
                    Text("¿Cuál es tu objetivo?", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Gap(14.dp)
                    Goal.values().forEach { g ->
                        Chip(g.label, goal == g, Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                            goal = g
                            if (weeks !in weekOptions(g)) weeks = weekOptions(g)[weekOptions(g).size / 2]
                        }
                    }
                }
                2 -> {
                    Text("¿Cuál es tu nivel?", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Gap(14.dp)
                    Level.values().forEach { l ->
                        Chip("${l.label} · ${l.desc}", level == l, Modifier.fillMaxWidth().padding(bottom = 8.dp)) { level = l }
                    }
                    Gap(10.dp)
                    Text("¿Tu mejor 5K reciente? (opcional)", color = Z.Muted)
                    Gap(6.dp)
                    OutlinedTextField(
                        value = fiveK, onValueChange = { fiveK = it.take(8) },
                        label = { Text("mm:ss, p. ej. 27:30") }, singleLine = true,
                        isError = !fiveKValid, modifier = Modifier.fillMaxWidth(), colors = fieldColors()
                    )
                    Text("Con él ajusto tus ritmos con más precisión. Si lo dejas vacío uso uno típico de tu nivel.", color = Z.Muted, fontSize = 12.sp)
                }
                3 -> {
                    Text("Tu semana de entreno", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Gap(14.dp)
                    Text("Días de carrera por semana", color = Z.Muted)
                    Gap(6.dp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (3..6).forEach { d -> Chip("$d", days == d, Modifier.weight(1f)) { days = d } }
                    }
                    Gap(16.dp)
                    Text("Duración del plan (semanas)", color = Z.Muted)
                    Gap(6.dp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        weekOptions(goal).forEach { w -> Chip("$w", weeks == w, Modifier.weight(1f)) { weeks = w } }
                    }
                    Gap(16.dp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Incluir sesión de fuerza semanal", Modifier.weight(1f).padding(end = 12.dp))
                        Switch(strength, { strength = it })
                    }
                    Gap(8.dp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Entrenador por voz", Modifier.weight(1f).padding(end = 12.dp))
                        Switch(voice, { voice = it })
                    }
                }
                else -> {
                    val vdot = PaceCalc.initialVdot(level, fiveKSec ?: 0)
                    val z = PaceZones.from(vdot)
                    Text("Todo listo${if (name.isNotBlank()) ", $name" else ""}", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Gap(14.dp)
                    ZCard {
                        Text("${goal.label} · $weeks semanas · $days días/semana", fontWeight = FontWeight.SemiBold)
                        Gap(8.dp)
                        Text("Tus ritmos de entrenamiento", color = Z.Muted, fontSize = 13.sp)
                        Gap(4.dp)
                        Text("Suave: ${Fmt.pace(z.easy)} /km", fontSize = 15.sp)
                        Text("Tempo: ${Fmt.pace(z.tempo)} /km", fontSize = 15.sp)
                        Text("Series: ${Fmt.pace(z.interval)} /km", fontSize = 15.sp)
                    }
                    Gap(10.dp)
                    Text(
                        "El plan se adapta: tras cada carrera puedes valorar cómo te sentiste y ajusto tus ritmos.",
                        color = Z.Muted, fontSize = 13.sp
                    )
                }
            }
        }
        val canNext = when (step) { 0 -> name.isNotBlank(); 2 -> fiveKValid; else -> true }
        if (step < total - 1) {
            PrimaryButton("Continuar", enabled = canNext) { step++ }
        } else {
            PrimaryButton(if (existing != null) "Guardar y recalcular plan" else "Crear mi plan") {
                val sec = fiveKSec ?: 0
                val vdotNew = if (existing != null && sec == 0 && existing.level == level) existing.vdot
                else PaceCalc.initialVdot(level, sec)
                state.restartPlan(
                    UserProfile(
                        name = name.trim(), goal = goal, level = level, daysPerWeek = days, planWeeks = weeks,
                        planStartEpochDay = LocalDate.now().toEpochDay(), recent5kSec = sec,
                        vdot = vdotNew, strength = strength, voiceCues = voice
                    )
                )
                state.editingPlan = false
                state.tab = 0
            }
        }
        if (step > 0) {
            Gap(8.dp)
            SecondaryButton("Atrás") { step-- }
        } else if (state.editingPlan) {
            Gap(8.dp)
            SecondaryButton("Cancelar") { state.editingPlan = false }
        }
    }
}
