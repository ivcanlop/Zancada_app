package com.zancada.app.tracking

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zancada.app.MainActivity
import com.zancada.app.core.Fmt
import com.zancada.app.core.LatLon
import com.zancada.app.core.RunRecord
import com.zancada.app.core.StepKind
import com.zancada.app.core.Workout
import com.zancada.app.data.Storage
import java.util.ArrayDeque
import java.util.Locale
import kotlin.math.abs

class RunService : Service(), LocationListener {

    companion object {
        const val ACTION_START = "com.zancada.app.START"
        const val ACTION_PAUSE = "com.zancada.app.PAUSE"
        const val ACTION_RESUME = "com.zancada.app.RESUME"
        const val ACTION_STOP = "com.zancada.app.STOP"
        private const val CHANNEL_ID = "zancada_run"
        private const val NOTIF_ID = 42

        fun send(context: Context, action: String) {
            val i = Intent(context, RunService::class.java).setAction(action)
            if (action == ACTION_START) ContextCompat.startForegroundService(context, i)
            else context.startService(i)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lm: LocationManager? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var status = RunStatus.IDLE
    private var workout: Workout? = null
    private var startMillis = 0L
    private var elapsed = 0
    private var distance = 0.0
    private var lastLoc: Location? = null
    private var accuracy = -1f
    private var gpsMessage = "Buscando GPS…"
    private val points = ArrayList<LatLon>()
    private val splits = ArrayList<Int>()
    private var lastSplitElapsed = 0
    private var nextKm = 1
    private val window = ArrayDeque<Pair<Int, Double>>() // (elapsed, distance)
    private var currentPace = 0

    private var stepIdx = 0
    private var stepEnds = DoubleArray(0)
    private var lastCoach = 0
    private var ticks = 0

    private val ticker = object : Runnable {
        override fun run() {
            if (status == RunStatus.RUNNING) {
                elapsed++
                ticks++
                coach()
            }
            publish()
            if (status == RunStatus.RUNNING && ticks % 5 == 0) updateNotification()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRun()
            ACTION_PAUSE -> pauseRun()
            ACTION_RESUME -> resumeRun()
            ACTION_STOP -> stopRun()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------ control
    private fun startRun() {
        if (status == RunStatus.RUNNING || status == RunStatus.PAUSED) return
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown(); ttsReady = false
        workout = RunSession.pendingWorkout
        stepEnds = DoubleArray(workout?.steps?.size ?: 0)
        var acc = 0.0
        workout?.steps?.forEachIndexed { i, s -> acc += s.distanceM; stepEnds[i] = acc }
        stepIdx = 0
        startMillis = System.currentTimeMillis()
        elapsed = 0; distance = 0.0; lastLoc = null; points.clear(); splits.clear()
        lastSplitElapsed = 0; nextKm = 1; window.clear(); currentPace = 0; lastCoach = 0; ticks = 0
        status = RunStatus.RUNNING

        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        tts = TextToSpeech(applicationContext) { code ->
            if (code == TextToSpeech.SUCCESS) {
                tts?.language = Locale("es", "ES")
                ttsReady = true
                val w = workout
                if (w != null && w.steps.isNotEmpty()) speak("Empezamos. ${describeStep(0)}")
                else speak("Empezamos la carrera")
            }
        }
        startLocation()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 1000)
        publish()
    }

    private fun pauseRun() {
        if (status != RunStatus.RUNNING) return
        status = RunStatus.PAUSED
        speak("Carrera en pausa")
        publish(); updateNotification()
    }

    private fun resumeRun() {
        if (status != RunStatus.PAUSED) return
        status = RunStatus.RUNNING
        lastLoc = null
        window.clear()
        speak("Seguimos")
        publish(); updateNotification()
    }

    private fun stopRun() {
        if (status != RunStatus.RUNNING && status != RunStatus.PAUSED) return
        handler.removeCallbacks(ticker)
        stopLocation()
        status = RunStatus.FINISHED
        var record: RunRecord? = null
        if (distance >= 50 && elapsed >= 20) {
            val w = workout
            record = RunRecord(
                id = startMillis,
                workoutId = w?.id,
                title = w?.title ?: "Carrera libre",
                distanceM = distance,
                durationSec = elapsed,
                points = downsample(points, 600),
                splitsSec = splits.toList(),
                feedback = 0
            )
            val storage = Storage(applicationContext)
            storage.addRun(record)
            if (w != null && w.totalDistanceM > 0 && distance >= w.totalDistanceM * 0.6) {
                storage.markDone(w.id, record.id)
            }
            speak("Carrera finalizada. ${Fmt.km(distance)} kilómetros en ${speechDuration(elapsed)}.")
        }
        RunSession.state.value = RunSession.state.value.copy(
            status = RunStatus.FINISHED, lastRecord = record, elapsedSec = elapsed, distanceM = distance
        )
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        handler.postDelayed({ stopSelf() }, 6000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopLocation()
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ GPS
    private fun startLocation() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
            gpsMessage = "Falta el permiso de ubicación"
            return
        }
        val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm = manager
        try {
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                gpsMessage = "Activa el GPS del móvil"
            }
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
        } catch (e: SecurityException) {
            gpsMessage = "Sin permiso de ubicación"
        } catch (e: Exception) {
            gpsMessage = "No se pudo iniciar el GPS"
        }
    }

    private fun stopLocation() {
        try { lm?.removeUpdates(this) } catch (_: Exception) {}
    }

    override fun onLocationChanged(loc: Location) {
        accuracy = loc.accuracy
        gpsMessage = if (loc.accuracy <= 20f) "GPS listo" else "Señal GPS débil"
        if (status != RunStatus.RUNNING) return
        if (loc.accuracy > 25f) return
        val prev = lastLoc
        if (prev == null) {
            lastLoc = loc
            points.add(LatLon(loc.latitude, loc.longitude))
            return
        }
        val d = prev.distanceTo(loc).toDouble()
        val dt = (loc.time - prev.time) / 1000.0
        if (dt <= 0) return
        if (d / dt > 12.0) return // velocidad imposible: salto de GPS
        if (d < 3.0) return        // ruido parado
        lastLoc = loc
        distance += d
        points.add(LatLon(loc.latitude, loc.longitude))
        updatePace()
        checkKm()
        checkStep()
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) { gpsMessage = "Buscando GPS…" }
    override fun onProviderDisabled(provider: String) { gpsMessage = "Activa el GPS del móvil" }

    // ------------------------------------------------------------ lógica
    private fun updatePace() {
        window.addLast(elapsed to distance)
        while (window.size > 1 && elapsed - window.peekFirst()!!.first > 25) window.removeFirst()
        val first = window.peekFirst()!!
        val dd = distance - first.second
        val dt = elapsed - first.first
        currentPace = if (dd > 8 && dt >= 8) (dt / dd * 1000).toInt() else currentPace
    }

    private fun checkKm() {
        while (distance >= nextKm * 1000.0) {
            val split = elapsed - lastSplitElapsed
            splits.add(split)
            lastSplitElapsed = elapsed
            val avg = (elapsed / (distance / 1000.0)).toInt()
            speak("Kilómetro $nextKm. Último kilómetro en ${Fmt.speechPace(split)}. Ritmo medio ${Fmt.speechPace(avg)}.")
            nextKm++
        }
    }

    private fun checkStep() {
        val w = workout ?: return
        if (stepIdx >= w.steps.size) return
        while (stepIdx < w.steps.size && distance >= stepEnds[stepIdx]) {
            stepIdx++
            lastCoach = elapsed
            if (stepIdx < w.steps.size) speak(describeStep(stepIdx))
            else speak("Entrenamiento completado. Puedes seguir a ritmo suave o terminar.")
        }
    }

    private fun describeStep(i: Int): String {
        val s = workout!!.steps[i]
        val dist = if (s.distanceM >= 1000) {
            val km = s.distanceM / 1000.0
            if (s.distanceM % 1000 == 0) "${s.distanceM / 1000} kilómetros" else String.format(Locale("es", "ES"), "%.1f kilómetros", km)
        } else "${s.distanceM} metros"
        return "${s.kind.label}. $dist a ${Fmt.speechPace(s.paceSecKm)} por kilómetro."
    }

    /** Avisos de ritmo cada 30 s en tramos con ritmo objetivo. */
    private fun coach() {
        val w = workout ?: return
        if (stepIdx >= w.steps.size || currentPace <= 0) return
        if (elapsed - lastCoach < 30) return
        val s = w.steps[stepIdx]
        if (s.kind == StepKind.WARMUP || s.kind == StepKind.COOLDOWN) return
        val stepStart = if (stepIdx == 0) 0.0 else stepEnds[stepIdx - 1]
        if (distance - stepStart < 150) return
        val diff = (currentPace - s.paceSecKm).toDouble() / s.paceSecKm
        if (abs(diff) > 0.08) {
            lastCoach = elapsed
            if (diff > 0) speak("Un poco más rápido. Ritmo actual ${Fmt.speechPace(currentPace)}.")
            else speak("Vas muy rápido, afloja un poco.")
        }
    }

    private fun speak(text: String) {
        if (!RunSession.voiceEnabled || !ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "z${System.nanoTime()}")
    }

    private fun speechDuration(sec: Int): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return buildString {
            if (h > 0) append("$h horas ")
            append("$m minutos $s segundos")
        }
    }

    private fun downsample(src: List<LatLon>, max: Int): List<LatLon> {
        if (src.size <= max) return src.toList()
        val step = src.size.toDouble() / max
        return (0 until max).map { src[(it * step).toInt()] }
    }

    private fun publish() {
        val w = workout
        val remaining = if (w != null && stepIdx < w.steps.size) (stepEnds[stepIdx] - distance).coerceAtLeast(0.0) else 0.0
        val cur = RunSession.state.value
        if (cur.status == RunStatus.FINISHED && status == RunStatus.FINISHED) return
        RunSession.state.value = RunUiState(
            status = status,
            elapsedSec = elapsed,
            distanceM = distance,
            paceSecKm = currentPace,
            gpsAccuracy = accuracy,
            gpsMessage = gpsMessage,
            stepIndex = stepIdx,
            stepRemainingM = remaining,
            workout = w,
            points = if (points.size > 400) points.takeLast(400) else points.toList(),
            lastRecord = null
        )
    }

    // ------------------------------------------------------------ notificación
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Carrera en curso", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val paused = status == RunStatus.PAUSED
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(if (paused) "Carrera en pausa" else "Corriendo")
            .setContentText("${Fmt.km(distance)} km · ${Fmt.duration(elapsed)}")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_WORKOUT)
            .build()
    }

    private fun updateNotification() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
    }
}
