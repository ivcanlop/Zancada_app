package com.zancada.app.data

import android.content.Context
import com.zancada.app.core.*
import org.json.JSONArray
import org.json.JSONObject

class Storage(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("zancada", Context.MODE_PRIVATE)

    // ---------- Perfil ----------
    fun loadProfile(): UserProfile? {
        val s = prefs.getString("profile", null) ?: return null
        return try {
            val o = JSONObject(s)
            UserProfile(
                name = o.getString("name"),
                goal = Goal.valueOf(o.getString("goal")),
                level = Level.valueOf(o.getString("level")),
                daysPerWeek = o.getInt("days"),
                planWeeks = o.getInt("weeks"),
                planStartEpochDay = o.getLong("start"),
                recent5kSec = o.getInt("recent5k"),
                vdot = o.getDouble("vdot"),
                strength = o.getBoolean("strength"),
                voiceCues = o.getBoolean("voice")
            )
        } catch (e: Exception) {
            null
        }
    }

    fun saveProfile(p: UserProfile) {
        val o = JSONObject()
            .put("name", p.name).put("goal", p.goal.name).put("level", p.level.name)
            .put("days", p.daysPerWeek).put("weeks", p.planWeeks).put("start", p.planStartEpochDay)
            .put("recent5k", p.recent5kSec).put("vdot", p.vdot)
            .put("strength", p.strength).put("voice", p.voiceCues)
        prefs.edit().putString("profile", o.toString()).apply()
    }

    // ---------- Carreras ----------
    fun loadRuns(): List<RunRecord> {
        val s = prefs.getString("runs", null) ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map { i -> fromJson(arr.getJSONObject(i)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveRuns(runs: List<RunRecord>) {
        val arr = JSONArray()
        runs.forEach { arr.put(toJson(it)) }
        prefs.edit().putString("runs", arr.toString()).apply()
    }

    @Synchronized
    fun addRun(r: RunRecord) {
        saveRuns(loadRuns() + r)
    }

    @Synchronized
    fun setFeedback(runId: Long, feedback: Int) {
        saveRuns(loadRuns().map { if (it.id == runId) it.copy(feedback = feedback) else it })
    }

    @Synchronized
    fun deleteRun(runId: Long) {
        saveRuns(loadRuns().filter { it.id != runId })
        val d = loadDone().filterValues { it != runId }
        saveDone(d)
    }

    // ---------- Entrenos completados (workoutId -> runId, 0 = marcado a mano) ----------
    fun loadDone(): Map<String, Long> {
        val s = prefs.getString("done", null) ?: return emptyMap()
        return try {
            val o = JSONObject(s)
            o.keys().asSequence().associateWith { o.getLong(it) }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun saveDone(m: Map<String, Long>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, v) }
        prefs.edit().putString("done", o.toString()).apply()
    }

    @Synchronized
    fun markDone(workoutId: String, runId: Long) {
        saveDone(loadDone() + (workoutId to runId))
    }

    @Synchronized
    fun unmarkDone(workoutId: String) {
        saveDone(loadDone() - workoutId)
    }

    fun clearDone() {
        saveDone(emptyMap())
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    private fun toJson(r: RunRecord): JSONObject {
        val pts = JSONArray()
        r.points.forEach { pts.put(JSONArray().put(it.lat).put(it.lon)) }
        val sp = JSONArray()
        r.splitsSec.forEach { sp.put(it) }
        return JSONObject()
            .put("id", r.id).put("wid", r.workoutId ?: "").put("title", r.title)
            .put("dist", r.distanceM).put("dur", r.durationSec)
            .put("pts", pts).put("splits", sp).put("fb", r.feedback)
    }

    private fun fromJson(o: JSONObject): RunRecord {
        val pts = o.getJSONArray("pts")
        val sp = o.getJSONArray("splits")
        return RunRecord(
            id = o.getLong("id"),
            workoutId = o.getString("wid").ifEmpty { null },
            title = o.getString("title"),
            distanceM = o.getDouble("dist"),
            durationSec = o.getInt("dur"),
            points = (0 until pts.length()).map { LatLon(pts.getJSONArray(it).getDouble(0), pts.getJSONArray(it).getDouble(1)) },
            splitsSec = (0 until sp.length()).map { sp.getInt(it) },
            feedback = o.getInt("fb")
        )
    }
}
