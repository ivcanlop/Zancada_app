package com.zancada.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zancada.app.core.Fmt
import com.zancada.app.core.Workout

@Composable
fun PlanScreen(state: AppState) {
    val cur = state.currentWeek()?.index ?: 0
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) { listState.scrollToItem(cur + 1) }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        state = listState,
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Plan de entrenamiento", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                val p = state.profile
                if (p != null) Text("${p.goal.label} · ${p.planWeeks} semanas · ${p.daysPerWeek} días/semana", color = Z.Muted, fontSize = 13.sp)
            }
        }
        itemsIndexed(state.plan) { _, week ->
            val isCur = week.index == cur
            ZCard(color = if (isCur) Z.VioletSoft else Z.Surface) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Semana ${week.index + 1}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(week.phase, color = Z.Muted, fontSize = 12.sp)
                    }
                    Text("${Fmt.km1(week.totalKm)} km", color = Z.Lime, fontWeight = FontWeight.Bold)
                }
                Gap(8.dp)
                week.workouts.forEach { w -> WorkoutRow(state, w) }
            }
        }
    }
}

@Composable
fun WorkoutRow(state: AppState, w: Workout) {
    val done = w.id in state.done
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { state.detail = w }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(dayShort(w.date), color = Z.Muted, fontSize = 11.sp)
            Text(w.date.dayOfMonth.toString(), fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Box(Modifier.width(4.dp).size(width = 4.dp, height = 36.dp).clip(RoundedCornerShape(2.dp)).background(typeColor(w.type)))
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(w.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                if (w.isRun) "${w.type.label} · ~${w.estimatedSec / 60} min" else "Sin GPS · ~25 min",
                color = Z.Muted, fontSize = 12.sp
            )
        }
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(if (done) Z.Lime else Z.Surface2),
            contentAlignment = Alignment.Center
        ) { if (done) Text("✓", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
    }
}
