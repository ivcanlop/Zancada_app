package com.zancada.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.zancada.app.core.LatLon
import com.zancada.app.core.Step
import com.zancada.app.core.StepKind
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

val ES = Locale("es", "ES")

fun dayShort(d: LocalDate): String =
    d.dayOfWeek.getDisplayName(TextStyle.SHORT, ES).replace(".", "").replaceFirstChar { it.uppercase() }

fun dayLong(d: LocalDate): String =
    d.dayOfWeek.getDisplayName(TextStyle.FULL, ES).replaceFirstChar { it.uppercase() } +
        " " + d.dayOfMonth + " " + d.month.getDisplayName(TextStyle.SHORT, ES).replace(".", "")

fun stepColor(k: StepKind): Color = when (k) {
    StepKind.WARMUP -> Z.Teal
    StepKind.WORK -> Z.Orange
    StepKind.RECOVERY -> Color(0xFF6FA8FF)
    StepKind.COOLDOWN -> Z.Teal
    StepKind.STEADY -> Z.Violet
}

/** Perfil visual del entrenamiento: barras proporcionales a la distancia y altas según intensidad. */
@Composable
fun StepProfileBar(steps: List<Step>, modifier: Modifier = Modifier, activeIndex: Int = -1) {
    if (steps.isEmpty()) return
    Row(
        modifier.fillMaxWidth().height(52.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        steps.forEachIndexed { i, s ->
            val h = when (s.kind) {
                StepKind.WORK -> 52
                StepKind.STEADY -> 32
                StepKind.RECOVERY -> 14
                else -> 20
            }
            val base = stepColor(s.kind)
            val c = if (activeIndex >= 0 && i != activeIndex) base.copy(alpha = 0.35f) else base
            Box(
                Modifier
                    .weight(max(s.distanceM, 100).toFloat())
                    .padding(horizontal = 1.dp)
                    .height(h.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(c)
            )
        }
    }
}

/** Dibuja la ruta GPS sin necesidad de mapas externos. */
@Composable
fun RouteCanvas(points: List<LatLon>, modifier: Modifier = Modifier, color: Color = Z.Lime) {
    Canvas(modifier) {
        if (points.size < 2) return@Canvas
        val minLat = points.minOf { it.lat }
        val maxLat = points.maxOf { it.lat }
        val minLon = points.minOf { it.lon }
        val maxLon = points.maxOf { it.lon }
        val midLat = (minLat + maxLat) / 2
        val kx = cos(Math.toRadians(midLat))
        val w = max((maxLon - minLon) * kx, 1e-6)
        val h = max(maxLat - minLat, 1e-6)
        val pad = 16f
        val scale = min((size.width - 2 * pad) / w.toFloat(), (size.height - 2 * pad) / h.toFloat())
        val offX = (size.width - w.toFloat() * scale) / 2
        val offY = (size.height - h.toFloat() * scale) / 2
        fun map(p: LatLon): Offset {
            val x = ((p.lon - minLon) * kx).toFloat() * scale + offX
            val y = size.height - (((p.lat - minLat).toFloat() * scale) + offY)
            return Offset(x, y)
        }
        val path = Path()
        points.forEachIndexed { i, p ->
            val o = map(p)
            if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
        }
        drawPath(path, color, style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(Z.Teal, 12f, map(points.first()))
        drawCircle(Z.Red, 12f, map(points.last()))
    }
}
