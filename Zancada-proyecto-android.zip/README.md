# Zancada — entrenador de running gratuito para Android

App nativa (Kotlin + Jetpack Compose). Sin anuncios, sin suscripción, sin cuenta: los datos se quedan en el móvil.

## Funciones
- Plan adaptado a tu objetivo (5K, 10K, media, maratón o mejorar forma), nivel, días/semana y duración
- Fases (base, construcción, específica, puesta a punto, carrera), semanas de descarga
- Rodajes, series, tempo, tirada larga (con final a ritmo de carrera) y fuerza
- Ritmos personalizados (VDOT) y marcas previstas; el plan se ajusta con tu valoración tras cada carrera
- Registro GPS en segundo plano, ritmo en tiempo real, parciales por km y ruta
- Entrenador por voz (avisos de tramo, km y corrección de ritmo)
- Historial, kilómetros semanales y marcas personales

## Obtener el APK (sin instalar nada)
1. Crea un repositorio vacío en GitHub y sube **todo el contenido** de esta carpeta (incluida `.github`).
2. En la pestaña **Actions** se ejecuta «Compilar APK» (≈5–8 min). Si no arranca, pulsa *Run workflow*.
3. Descarga `Zancada.apk` desde **Releases** (o desde el artefacto del workflow) e instálalo en el móvil
   (permite «instalar apps de origen desconocido»).

## Compilar en tu ordenador
Android Studio → abrir carpeta → *Build > Build APK(s)*, o `./gradlew assembleRelease`
(APK en `app/build/outputs/apk/release/`).
